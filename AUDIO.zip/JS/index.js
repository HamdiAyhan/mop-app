
import { UIGoster } from "./Fonksiyonlar.js";

UIGoster()