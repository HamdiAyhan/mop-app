const modlar=[
{mod : 'beach',tr:'Plsaj Sesi'},
{mod : 'birds',tr:' Kuşlar Sesi'},
{mod : 'cafe',tr:'Kafe Ortamı'},
{mod : 'campfire',tr:'Kamp Ateşi'},
{mod : 'city',tr:'Şehir'},
{mod : 'fireplace',tr:'Şömine'},
{mod : 'forest',tr:'Orman'},
{mod : 'heavy-rain',tr:'Sağanak Yağış'},
{mod : 'night-crickets',tr:'Ağustos Böceği'},
{mod : 'rain-camping',tr:'Yağmurda Kamp'},
{mod : 'rain' , tr:'Yağmur'},
{mod : 'rain-windshield',tr:'Cama Düşen Yağmur'},
{mod : 'snow',tr:'Kar'},
{mod : 'thunder',tr:'GökGürültüsü'},
{mod : 'train',tr:'Tren'},
]
export {modlar}